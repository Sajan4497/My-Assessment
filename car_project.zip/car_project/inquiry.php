<?php
require_once 'includes/functions.php';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $carOptions = $_POST['car_options'] ?? [];

    // Validation
    if (empty($name) || empty($phone) || empty($email) || empty($address)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (empty($carOptions)) {
        $error = 'Please select at least one car type.';
    } else {
        if (saveInquiry($name, $phone, $email, $address, $carOptions)) {
            $success = true;
        } else {
            $error = 'Failed to submit inquiry. Please try again.';
        }
    }
}

$siteTitle = getConfig('site_title') ?: 'Cars
Bazaar';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inquiry -
        <?php echo htmlspecialchars($siteTitle); ?>
    </title>
    <meta name="description" content="Submit your car inquiry and let us help you find your perfect vehicle.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    
    <header class="header">
        <div class="header-container">
            <a href="index.php" class="logo">
                <div class="logo-icon"></div>
                Cars<span>Bazaar</span>
            </a>
            <nav class="nav">
                <a href="index.php" class="nav-link">Home</a>
                <a href="index.php#most-searched" class="nav-link">Popular Cars</a>
                <a href="index.php#latest" class="nav-link">Latest Cars</a>
                <a href="inquiry.php" class="btn btn-primary">Get Quote</a>
            </nav>
        </div>
    </header>

    
    <section class="section form-section" style="padding-top: 120px; min-height: 100vh;">
        <div class="form-container">
            <h1 class="form-title">Get Your <span style="color: var(--primary);">Dream Car</span></h1>
            <p class="form-subtitle">Fill out the form below and we'll get back to you shortly</p>

            <?php if ($success): ?>
                <div class="alert alert-success">
                     Thank you! Your inquiry has been submitted successfully. We will contact you soon.
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="inquiry.php">
                
                <div class="form-group">
                    <label class="form-label">Select Car Type *</label>
                    <div class="checkbox-group">
                        <label class="checkbox-item">
                            <input type="checkbox" name="car_options[]" value="Hatchback">
                            <span class="checkbox-custom"></span>
                            <span class="checkbox-label"> Hatchback</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="car_options[]" value="Sedan">
                            <span class="checkbox-custom"></span>
                            <span class="checkbox-label">Sedan</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="car_options[]" value="SUV">
                            <span class="checkbox-custom"></span>
                            <span class="checkbox-label">SUV</span>
                        </label>
                    </div>
                </div>

            
                <div class="form-group">
                    <label class="form-label" for="name">Full Name *</label>
                    <input type="text" id="name" name="name" class="form-input" placeholder="Enter your full name"
                        required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                </div>

                
                <div class="form-group">
                    <label class="form-label" for="phone">Phone Number *</label>
                    <input type="tel" id="phone" name="phone" class="form-input" placeholder="Enter your phone number"
                        required value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                </div>

                
                <div class="form-group">
                    <label class="form-label" for="email">Email Address *</label>
                    <input type="email" id="email" name="email" class="form-input"
                        placeholder="Enter your email address" required
                        value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>

                
                <div class="form-group">
                    <label class="form-label" for="address">Address *</label>
                    <textarea id="address" name="address" class="form-input" placeholder="Enter your full address"
                        required><?php echo htmlspecialchars($_POST['address'] ?? ''); ?></textarea>
                </div>

                
                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">
                    Submit Inquiry
                </button>
            </form>
        </div>
    </section>

    
    <footer class="footer">
        <div class="footer-container">
            <div>
                <div class="footer-brand">Cars<span>Dekho</span></div>
                <p class="footer-description">Find your perfect car with India's leading automobile platform.</p>
            </div>
            <div>
                <h4 class="footer-title">Quick Links</h4>
                <ul class="footer-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="inquiry.php">Get Quote</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div>
                <h4 class="footer-title">Car Types</h4>
                <ul class="footer-links">
                    <li><a href="#">Hatchback</a></li>
                    <li><a href="#">Sedan</a></li>
                    <li><a href="#">SUV</a></li>
                    <li><a href="#">Electric</a></li>
                </ul>
            </div>
            <div>
                <h4 class="footer-title">Contact Info</h4>
                <ul class="footer-links">
                    <li>
                        <?php echo htmlspecialchars(getConfig('contact_email') ?: 'info@carsdekho.com'); ?>
                    </li>
                    <li>
                        <?php echo htmlspecialchars(getConfig('contact_phone') ?: '+91 9876543210'); ?>
                    </li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>
                <?php echo htmlspecialchars(getConfig('footer_text') ?: '© 2026 CarsDekho. All Rights Reserved.'); ?>
            </p>
        </div>
    </footer>
</body>

</html>