-- Insert Cars Data for CarsDekho
-- Run this SQL after creating the database schema
-- Cars from Tata, Maruti Suzuki, Volkswagen, Hyundai, Honda, Toyota, Mahindra, Kia, and more

USE car_project;

-- Clear existing car data (optional)
-- DELETE FROM cars;

-- ============================================
-- TATA MOTORS
-- ============================================

-- Tata Nexon (Most Searched - SUV)
INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Tata Nexon', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/141867/nexon-exterior-right-front-three-quarter-71.jpeg?isig=0&q=80', 'most_searched', 799000, 'Petrol/Diesel/Electric', 'Manual/AMT/Automatic'),
('Tata Nexon EV', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/141383/nexon-ev-exterior-right-front-three-quarter-60.jpeg?isig=0&q=80', 'latest', 1499000, 'Electric', 'Automatic'),
('Tata Punch', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144681/punch-exterior-right-front-three-quarter-11.jpeg?isig=0&q=80', 'most_searched', 599000, 'Petrol/CNG', 'Manual/AMT'),
('Tata Harrier', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139651/harrier-facelift-exterior-right-front-three-quarter-2.jpeg?isig=0&q=80', 'latest', 1599000, 'Diesel', 'Manual/Automatic'),
('Tata Safari', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/115093/safari-exterior-right-front-three-quarter-5.jpeg?isig=0&q=80', 'latest', 1599000, 'Diesel', 'Manual/Automatic'),
('Tata Altroz', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/altroz-exterior-right-front-three-quarter-74.jpeg?isig=0&q=80', 'most_searched', 649000, 'Petrol/Diesel/CNG', 'Manual/DCA'),
('Tata Tiago', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139139/tiago-nrg-exterior-right-front-three-quarter-3.jpeg?isig=0&q=80', 'most_searched', 529000, 'Petrol/CNG', 'Manual/AMT'),
('Tata Tigor', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/115025/tigor-exterior-right-front-three-quarter-2.jpeg?isig=0&q=80', 'most_searched', 599000, 'Petrol/CNG', 'Manual/AMT'),
('Tata Curvv', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/156405/curvv-exterior-right-front-three-quarter-33.jpeg?isig=0&q=80', 'latest', 999000, 'Petrol/Diesel', 'Manual/Automatic'),
('Tata Curvv EV', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/156405/curvv-ev-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 1799000, 'Electric', 'Automatic');

-- ============================================
-- MARUTI SUZUKI
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Maruti Suzuki Swift', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/159099/swift-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'most_searched', 599000, 'Petrol/CNG', 'Manual/AMT'),
('Maruti Suzuki Brezza', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/107543/brezza-exterior-right-front-three-quarter-7.jpeg?isig=0&q=80', 'most_searched', 849000, 'Petrol/CNG', 'Manual/Automatic'),
('Maruti Suzuki Wagon R', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144793/wagon-r-exterior-right-front-three-quarter-21.jpeg?isig=0&q=80', 'most_searched', 565000, 'Petrol/CNG', 'Manual/AMT'),
('Maruti Suzuki Baleno', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/102663/baleno-exterior-right-front-three-quarter-67.jpeg?isig=0&q=80', 'most_searched', 649000, 'Petrol/CNG', 'Manual/AMT'),
('Maruti Suzuki Alto K10', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/45691/alto-k10-exterior-right-front-three-quarter-4.jpeg?isig=0&q=80', 'most_searched', 399000, 'Petrol/CNG', 'Manual/AMT'),
('Maruti Suzuki Ertiga', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/51909/ertiga-exterior-right-front-three-quarter-20.jpeg?isig=0&q=80', 'most_searched', 899000, 'Petrol/CNG', 'Manual/Automatic'),
('Maruti Suzuki Grand Vitara', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/115777/grand-vitara-exterior-right-front-three-quarter-4.jpeg?isig=0&q=80', 'latest', 1099000, 'Petrol/Hybrid', 'Manual/Automatic'),
('Maruti Suzuki Fronx', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/fronx-exterior-right-front-three-quarter-110.jpeg?isig=0&q=80', 'latest', 749000, 'Petrol', 'Manual/AMT'),
('Maruti Suzuki Dzire', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/159099/dzire-exterior-right-front-three-quarter-2.jpeg?isig=0&q=80', 'most_searched', 649000, 'Petrol/CNG', 'Manual/AMT'),
('Maruti Suzuki Celerio', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/41386/celerio-exterior-right-front-three-quarter-3.jpeg?isig=0&q=80', 'most_searched', 529000, 'Petrol/CNG', 'Manual/AMT'),
('Maruti Suzuki Jimny', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139739/jimny-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 1274000, 'Petrol', 'Manual/Automatic'),
('Maruti Suzuki XL6', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/53695/xl6-exterior-right-front-three-quarter-79.jpeg?isig=0&q=80', 'latest', 1149000, 'Petrol/CNG', 'Manual/Automatic');

-- ============================================
-- VOLKSWAGEN
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Volkswagen Virtus', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144681/virtus-exterior-right-front-three-quarter-7.jpeg?isig=0&q=80', 'latest', 1199000, 'Petrol', 'Manual/Automatic'),
('Volkswagen Taigun', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139139/taigun-exterior-right-front-three-quarter-36.jpeg?isig=0&q=80', 'latest', 1199000, 'Petrol', 'Manual/Automatic'),
('Volkswagen Tiguan', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/158681/tiguan-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 3599000, 'Petrol', 'Automatic');

-- ============================================
-- HYUNDAI
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Hyundai Creta', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/106815/creta-exterior-right-front-three-quarter-4.jpeg?isig=0&q=80', 'most_searched', 1099000, 'Petrol/Diesel', 'Manual/Automatic'),
('Hyundai Venue', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/141113/venue-exterior-right-front-three-quarter-3.jpeg?isig=0&q=80', 'most_searched', 799000, 'Petrol/Diesel', 'Manual/Automatic'),
('Hyundai Verna', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/142515/verna-exterior-right-front-three-quarter-21.jpeg?isig=0&q=80', 'latest', 1099000, 'Petrol/Diesel', 'Manual/Automatic'),
('Hyundai i20', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139139/i20-exterior-right-front-three-quarter-5.jpeg?isig=0&q=80', 'most_searched', 749000, 'Petrol', 'Manual/Automatic'),
('Hyundai Grand i10 Nios', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/grand-i10-nios-exterior-right-front-three-quarter-70.jpeg?isig=0&q=80', 'most_searched', 599000, 'Petrol/CNG', 'Manual/AMT'),
('Hyundai Exter', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/156405/exter-exterior-right-front-three-quarter-15.jpeg?isig=0&q=80', 'latest', 649000, 'Petrol/CNG', 'Manual/AMT'),
('Hyundai Alcazar', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144681/alcazar-facelift-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 1599000, 'Petrol/Diesel', 'Manual/Automatic'),
('Hyundai Tucson', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139651/tucson-exterior-right-front-three-quarter-2.jpeg?isig=0&q=80', 'latest', 2999000, 'Petrol/Diesel', 'Automatic'),
('Hyundai Ioniq 5', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/156197/ioniq-5-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 4599000, 'Electric', 'Automatic');

-- ============================================
-- HONDA
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Honda City', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/134287/city-exterior-right-front-three-quarter-77.jpeg?isig=0&q=80', 'most_searched', 1199000, 'Petrol/Hybrid', 'Manual/CVT'),
('Honda Amaze', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/159233/amaze-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'most_searched', 799000, 'Petrol', 'Manual/CVT'),
('Honda Elevate', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/156197/elevate-exterior-right-front-three-quarter-3.jpeg?isig=0&q=80', 'latest', 1199000, 'Petrol', 'Manual/CVT');

-- ============================================
-- TOYOTA
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Toyota Fortuner', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139139/fortuner-exterior-right-front-three-quarter-6.jpeg?isig=0&q=80', 'most_searched', 3349000, 'Diesel', 'Manual/Automatic'),
('Toyota Innova Crysta', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/115025/innova-crysta-exterior-right-front-three-quarter-2.jpeg?isig=0&q=80', 'most_searched', 1999000, 'Petrol/Diesel', 'Manual/Automatic'),
('Toyota Innova Hycross', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144793/innova-hycross-exterior-right-front-three-quarter-73.jpeg?isig=0&q=80', 'latest', 1999000, 'Hybrid', 'Automatic'),
('Toyota Hilux', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139651/hilux-exterior-right-front-three-quarter-6.jpeg?isig=0&q=80', 'latest', 3699000, 'Diesel', 'Manual/Automatic'),
('Toyota Urban Cruiser Hyryder', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139139/urban-cruiser-hyryder-exterior-right-front-three-quarter-73.jpeg?isig=0&q=80', 'latest', 1099000, 'Petrol/Hybrid', 'Manual/Automatic'),
('Toyota Glanza', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/115777/glanza-exterior-right-front-three-quarter-6.jpeg?isig=0&q=80', 'most_searched', 699000, 'Petrol/CNG', 'Manual/AMT'),
('Toyota Camry', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144793/camry-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 4699000, 'Hybrid', 'Automatic');

-- ============================================
-- MAHINDRA
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Mahindra Scorpio-N', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/scorpio-n-exterior-right-front-three-quarter-75.jpeg?isig=0&q=80', 'most_searched', 1349000, 'Petrol/Diesel', 'Manual/Automatic'),
('Mahindra XUV700', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/112015/xuv-700-exterior-right-front-three-quarter-4.jpeg?isig=0&q=80', 'most_searched', 1399000, 'Petrol/Diesel', 'Manual/Automatic'),
('Mahindra Thar', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/thar-exterior-right-front-three-quarter-75.jpeg?isig=0&q=80', 'most_searched', 1099000, 'Petrol/Diesel', 'Manual/Automatic'),
('Mahindra Scorpio Classic', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/scorpio-classic-exterior-right-front-three-quarter-6.jpeg?isig=0&q=80', 'most_searched', 1399000, 'Diesel', 'Manual'),
('Mahindra XUV300', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/39053/xuv300-exterior-right-front-three-quarter-11.jpeg?isig=0&q=80', 'most_searched', 849000, 'Petrol/Diesel', 'Manual/AMT'),
('Mahindra Bolero', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/40453/bolero-exterior-right-front-three-quarter-11.jpeg?isig=0&q=80', 'most_searched', 999000, 'Diesel', 'Manual'),
('Mahindra XUV400 EV', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144681/xuv400-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 1599000, 'Electric', 'Automatic'),
('Mahindra XUV 3XO', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/156405/xuv-3xo-exterior-right-front-three-quarter-10.jpeg?isig=0&q=80', 'latest', 849000, 'Petrol/Diesel', 'Manual/Automatic');

-- ============================================
-- KIA
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Kia Seltos', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/seltos-exterior-right-front-three-quarter-62.jpeg?isig=0&q=80', 'most_searched', 1099000, 'Petrol/Diesel', 'Manual/Automatic'),
('Kia Sonet', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/sonet-exterior-right-front-three-quarter-154.jpeg?isig=0&q=80', 'most_searched', 799000, 'Petrol/Diesel', 'Manual/Automatic'),
('Kia Carens', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/127563/carens-exterior-right-front-three-quarter-YT.jpeg?isig=0&q=80', 'latest', 1099000, 'Petrol/Diesel', 'Manual/Automatic'),
('Kia EV6', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/142515/ev6-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 6099000, 'Electric', 'Automatic');

-- ============================================
-- RENAULT
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Renault Kiger', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144793/kiger-exterior-right-front-three-quarter-3.jpeg?isig=0&q=80', 'most_searched', 649000, 'Petrol', 'Manual/AMT'),
('Renault Triber', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/45691/triber-exterior-right-front-three-quarter-4.jpeg?isig=0&q=80', 'most_searched', 599000, 'Petrol/CNG', 'Manual/AMT');

-- ============================================
-- NISSAN
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Nissan Magnite', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/141113/magnite-exterior-right-front-three-quarter-3.jpeg?isig=0&q=80', 'most_searched', 649000, 'Petrol', 'Manual/CVT');

-- ============================================
-- SKODA
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Skoda Kushaq', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/kushaq-exterior-right-front-three-quarter-75.jpeg?isig=0&q=80', 'latest', 1199000, 'Petrol', 'Manual/Automatic'),
('Skoda Slavia', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/slavia-exterior-right-front-three-quarter-76.jpeg?isig=0&q=80', 'latest', 1199000, 'Petrol', 'Manual/Automatic');

-- ============================================
-- MG (Morris Garages)
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('MG Hector', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144793/hector-exterior-right-front-three-quarter-3.jpeg?isig=0&q=80', 'most_searched', 1499000, 'Petrol/Hybrid', 'Manual/Automatic'),
('MG Astor', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/144793/astor-exterior-right-front-three-quarter-7.jpeg?isig=0&q=80', 'latest', 1099000, 'Petrol', 'Manual/CVT'),
('MG Comet EV', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/156197/comet-ev-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 799000, 'Electric', 'Automatic'),
('MG ZS EV', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/147583/zs-ev-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 2399000, 'Electric', 'Automatic');

-- ============================================
-- CITROEN
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Citroen C3', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139651/c3-exterior-right-front-three-quarter-2.jpeg?isig=0&q=80', 'latest', 649000, 'Petrol', 'Manual'),
('Citroen C3 Aircross', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/156197/c3-aircross-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 999000, 'Petrol', 'Manual/Automatic');

-- ============================================
-- JEEP
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Jeep Compass', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/141113/compass-facelift-exterior-right-front-three-quarter.jpeg?isig=0&q=80', 'latest', 1999000, 'Petrol/Diesel', 'Manual/Automatic'),
('Jeep Meridian', 'https://imgd.aeplcdn.com/664x374/n/cw/ec/139651/meridian-exterior-right-front-three-quarter-6.jpeg?isig=0&q=80', 'latest', 2999000, 'Diesel', 'Manual/Automatic');

-- Success message
SELECT 'Cars inserted successfully!' AS Status, COUNT(*) AS TotalCars FROM cars;
