-- Insert Cars Data - 3 Cars per Brand (6 Brands = 18 Cars)
-- Run this SQL after creating the database schema

USE car_project;

-- Clear existing car data
DELETE FROM cars;

-- ============================================
-- TATA MOTORS (3 Cars)
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Tata Nexon', 'assets/cars/tata_nexon.png', 'most_searched', 799000, 'Petrol/Diesel/Electric', 'Manual/AMT'),
('Tata Punch', 'assets/cars/tata_punch.png', 'most_searched', 599000, 'Petrol/CNG', 'Manual/AMT'),
('Tata Altroz', 'assets/cars/tata_altroz.png', 'latest', 649000, 'Petrol/Diesel', 'Manual/DCA');

-- ============================================
-- MARUTI SUZUKI (3 Cars)
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Maruti Suzuki Swift', 'assets/cars/maruti_swift.png', 'most_searched', 599000, 'Petrol/CNG', 'Manual/AMT'),
('Maruti Suzuki Brezza', 'assets/cars/maruti_brezza.png', 'most_searched', 849000, 'Petrol/CNG', 'Manual/Automatic'),
('Maruti Suzuki Baleno', 'assets/cars/maruti_baleno.png', 'latest', 649000, 'Petrol/CNG', 'Manual/AMT');

-- ============================================
-- VOLKSWAGEN (3 Cars)
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Volkswagen Virtus', 'assets/cars/volkswagen_virtus.png', 'latest', 1199000, 'Petrol', 'Manual/Automatic'),
('Volkswagen Taigun', 'assets/cars/volkswagen_taigun.png', 'latest', 1199000, 'Petrol', 'Manual/Automatic'),
('Volkswagen Polo', 'assets/cars/volkswagen_polo.png', 'most_searched', 699000, 'Petrol', 'Manual/Automatic');

-- ============================================
-- HYUNDAI (3 Cars)
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Hyundai Creta', 'assets/cars/hyundai_creta.png', 'most_searched', 1099000, 'Petrol/Diesel', 'Manual/Automatic'),
('Hyundai Venue', 'assets/cars/hyundai_venue.png', 'most_searched', 799000, 'Petrol/Diesel', 'Manual/Automatic'),
('Hyundai i20', 'assets/cars/hyundai_i20.png', 'latest', 749000, 'Petrol', 'Manual/Automatic');

-- ============================================
-- MAHINDRA (3 Cars)
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Mahindra Scorpio-N', 'assets/cars/mahindra_scorpio.png', 'most_searched', 1349000, 'Petrol/Diesel', 'Manual/Automatic'),
('Mahindra XUV700', 'assets/cars/mahindra_xuv700.png', 'latest', 1399000, 'Petrol/Diesel', 'Manual/Automatic'),
('Mahindra Thar', 'assets/cars/mahindra_thar.png', 'most_searched', 1099000, 'Petrol/Diesel', 'Manual/Automatic');

-- ============================================
-- HONDA (3 Cars)
-- ============================================

INSERT INTO cars (name, image_path, section, price, fuel_type, transmission) VALUES 
('Honda City', 'assets/cars/honda_city.png', 'most_searched', 1199000, 'Petrol/Hybrid', 'Manual/CVT'),
('Honda Amaze', 'assets/cars/honda_amaze.png', 'most_searched', 799000, 'Petrol', 'Manual/CVT'),
('Honda Elevate', 'assets/cars/honda_elevate.png', 'latest', 1199000, 'Petrol', 'Manual/CVT');

-- Success message
SELECT 'Cars inserted successfully!' AS Status, COUNT(*) AS TotalCars FROM cars;
