# Car Database Documentation

## Overview
This database contains a comprehensive collection of popular Indian cars from major manufacturers.

## Included Car Brands

### 🚗 Indian Brands
- **Tata Motors** - 10 models (Nexon, Punch, Harrier, Safari, Altroz, Tiago, Tigor, Curvv, and EV variants)
- **Mahindra** - 8 models (Scorpio-N, XUV700, Thar, XUV300, Bolero, XUV 3XO, XUV400 EV)

### 🌏 Japanese Brands
- **Maruti Suzuki** - 12 models (Swift, Brezza, Wagon R, Baleno, Alto K10, Ertiga, Grand Vitara, Fronx, Dzire, Celerio, Jimny, XL6)
- **Honda** - 3 models (City, Amaze, Elevate)
- **Toyota** - 7 models (Fortuner, Innova Crysta, Innova Hycross, Hilux, Hyryder, Glanza, Camry)
- **Nissan** - 1 model (Magnite)

### 🇰🇷 Korean Brands
- **Hyundai** - 9 models (Creta, Venue, Verna, i20, Grand i10 Nios, Exter, Alcazar, Tucson, Ioniq 5)
- **Kia** - 4 models (Seltos, Sonet, Carens, EV6)

### 🇩🇪 German Brands
- **Volkswagen** - 3 models (Virtus, Taigun, Tiguan)
- **Skoda** - 2 models (Kushaq, Slavia)

### 🇬🇧 British/Chinese Brands
- **MG Motors** - 4 models (Hector, Astor, Comet EV, ZS EV)
- **Jeep** - 2 models (Compass, Meridian)

### 🇫🇷 French Brands
- **Renault** - 2 models (Kiger, Triber)
- **Citroen** - 2 models (C3, C3 Aircross)

## Total Cars: 90+ Models

## Car Details Included

Each car entry includes:
- **Name** - Full car model name
- **Image Path** - High-quality car image URL
- **Section** - Category (most_searched or latest)
- **Price** - Starting price in INR (Indian Rupees)
- **Fuel Type** - Available fuel options (Petrol, Diesel, CNG, Electric, Hybrid)
- **Transmission** - Available transmission types (Manual, Automatic, AMT, CVT, DCA)

## How to Import the Data

### Method 1: Using phpMyAdmin
1. Open phpMyAdmin (usually at http://localhost/phpmyadmin)
2. Select the `car_project` database from the left sidebar
3. Click on the "Import" tab
4. Click "Choose File" and select `insert_cars.sql`
5. Click "Go" at the bottom
6. Wait for the success message

### Method 2: Using MySQL Command Line
```bash
# Navigate to the database folder
cd c:\xam\htdocs\car_project\database

# Import the file
mysql -u root -p car_project < insert_cars.sql
```

### Method 3: Copy and Paste
1. Open `insert_cars.sql` in a text editor
2. Copy all the SQL content
3. Open phpMyAdmin
4. Select the `car_project` database
5. Click on the "SQL" tab
6. Paste the content
7. Click "Go"

## Car Categorization

### Most Searched Cars (Popular Models)
These are the cars that customers frequently search for:
- Budget hatchbacks: Alto K10, Celerio, Tiago
- Popular sedans: Swift, Baleno, City, Dzire
- SUVs: Creta, Nexon, Brezza, Seltos, Scorpio-N, XUV700, Thar

### Latest Cars (New Launches)
These are recently launched models:
- Electric vehicles: Nexon EV, Curvv EV, Ioniq 5, XUV400 EV
- New SUVs: Harrier, Safari, Curvv, Grand Vitara, Exter
- Premium models: Virtus, Taigun, Elevate, Innova Hycross

## Price Range

- **Budget Cars (Under ₹6 Lakhs)**
  - Maruti Alto K10, Celerio, Wagon R
  - Tata Tiago, Punch
  - Hyundai Grand i10 Nios, Exter
  - Renault Kiger, Triber

- **Mid-Range Cars (₹6-15 Lakhs)**
  - Maruti Swift, Brezza, Baleno, Dzire, Fronx
  - Hyundai i20, Venue, Verna
  - Tata Altroz, Tigor, Nexon
  - Honda Amaze, City
  - Kia Sonet, Seltos

- **Premium Cars (₹15-35 Lakhs)**
  - Hyundai Creta, Alcazar
  - Mahindra Scorpio-N, XUV700, Thar
  - Toyota Fortuner, Innova Crysta
  - Volkswagen Virtus, Taigun, Tiguan

- **Luxury/Electric Cars (Above ₹35 Lakhs)**
  - Hyundai Ioniq 5
  - Toyota Camry
  - Kia EV6
  - Jeep Compass, Meridian

## Fuel Type Distribution

- **Petrol** - Most common, available in almost all models
- **Diesel** - Available in SUVs and premium sedans
- **CNG** - Budget-friendly option in hatchbacks and sedans
- **Electric** - Growing segment with Nexon EV, Curvv EV, Ioniq 5, etc.
- **Hybrid** - Toyota Hyryder, Grand Vitara, Innova Hycross, City

## Transmission Types

- **Manual** - Traditional stick shift (most affordable)
- **Automatic** - Torque converter (smooth, premium)
- **AMT** - Automated Manual Transmission (budget automatic)
- **CVT** - Continuously Variable Transmission (efficient)
- **DCA** - Dual Clutch Automatic (sporty, responsive)

## Maintenance

To update car data:
1. Edit the `insert_cars.sql` file
2. Re-import it (it will add new entries)
3. Or use the admin panel at `admin/index.php?section=cars`

To clear all car data before importing:
```sql
DELETE FROM cars;
```

## Notes

- All prices are approximate starting prices (ex-showroom)
- Images are sourced from official automotive websites
- Car availability may vary by region
- Prices and specifications are subject to change by manufacturers

## Support

For issues or questions:
- Check the main `schema.sql` for database structure
- Ensure the database and tables are created before importing
- Verify image URLs are accessible
- Use the admin panel for easy car management
