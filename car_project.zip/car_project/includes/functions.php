<?php
require_once __DIR__ . '/db.php';

/* -------------------------
   Site Config
--------------------------*/

// Get site configuration
function getConfig($key)
{
    global $conn;

    $stmt = $conn->prepare("SELECT config_value FROM site_config WHERE config_key = ?");
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    return $result ? $result['config_value'] : '';
}

// Update site configuration
function updateConfig($key, $value)
{
    global $conn;

    $stmt = $conn->prepare(
        "INSERT INTO site_config (config_key, config_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE config_value = ?"
    );
    $stmt->bind_param("sss", $key, $value, $value);
    return $stmt->execute();
}

/* -------------------------
   Banners
--------------------------*/

// Get all banners
function getBanners()
{
    global $conn;

    $data = [];
    $result = $conn->query("SELECT * FROM banners ORDER BY display_order ASC");

    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    return $data;
}

// Add banner
function addBanner($imagePath, $title = '', $subtitle = '', $order = 0)
{
    global $conn;

    $stmt = $conn->prepare(
        "INSERT INTO banners (image_path, title, subtitle, display_order)
         VALUES (?, ?, ?, ?)"
    );
    $stmt->bind_param("sssi", $imagePath, $title, $subtitle, $order);
    return $stmt->execute();
}

// Delete banner
function deleteBanner($id)
{
    global $conn;

    $stmt = $conn->prepare("SELECT image_path FROM banners WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $banner = $stmt->get_result()->fetch_assoc();

    if ($banner && file_exists(__DIR__ . '/../' . $banner['image_path'])) {
        unlink(__DIR__ . '/../' . $banner['image_path']);
    }

    $stmt = $conn->prepare("DELETE FROM banners WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

/* -------------------------
   Cars
--------------------------*/

// Get cars by section
function getCarsBySection($section)
{
    global $conn;

    $data = [];
    $stmt = $conn->prepare(
        "SELECT * FROM cars WHERE section = ? ORDER BY created_at DESC"
    );
    $stmt->bind_param("s", $section);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    return $data;
}

// Get all cars
function getAllCars()
{
    global $conn;

    $data = [];
    $result = $conn->query("SELECT * FROM cars ORDER BY created_at DESC");

    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    return $data;
}

// Add car
function addCar($name, $imagePath, $section, $price, $fuelType = '', $transmission = '')
{
    global $conn;

    $stmt = $conn->prepare(
        "INSERT INTO cars (name, image_path, section, price, fuel_type, transmission)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("sssiss", $name, $imagePath, $section, $price, $fuelType, $transmission);
    return $stmt->execute();
}

// Delete car
function deleteCar($id)
{
    global $conn;

    $stmt = $conn->prepare("SELECT image_path FROM cars WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $car = $stmt->get_result()->fetch_assoc();

    if ($car && file_exists(__DIR__ . '/../' . $car['image_path'])) {
        unlink(__DIR__ . '/../' . $car['image_path']);
    }

    $stmt = $conn->prepare("DELETE FROM cars WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

/* -------------------------
   Inquiry
--------------------------*/

// Save inquiry
function saveInquiry($name, $phone, $email, $address, $carOptions)
{
    global $conn;

    $options = is_array($carOptions) ? implode(', ', $carOptions) : $carOptions;

    $stmt = $conn->prepare(
        "INSERT INTO inquiries (name, phone, email, address, car_options)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("sssss", $name, $phone, $email, $address, $options);
    return $stmt->execute();
}

// Get all inquiries
function getAllInquiries()
{
    global $conn;

    $data = [];
    $result = $conn->query("SELECT * FROM inquiries ORDER BY created_at DESC");

    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    return $data;
}

/* -------------------------
   Image Upload
--------------------------*/

function uploadImage($file, $folder = 'uploads')
{
    $targetDir = __DIR__ . '/../assets/' . $folder . '/';

    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $fileName = time() . '_' . basename($file['name']);
    $targetPath = $targetDir . $fileName;
    $relativePath = 'assets/' . $folder . '/' . $fileName;

    $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    if (!in_array($ext, $allowed)) {
        return ['success' => false, 'message' => 'Invalid image format'];
    }

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => true, 'path' => $relativePath];
    }

    return ['success' => false, 'message' => 'Upload failed'];
}
