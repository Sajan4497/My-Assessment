<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

require_once '../includes/functions.php';

$section = $_GET['section'] ?? 'dashboard';
$message = '';
$messageType = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'update_config':
            foreach ($_POST['config'] as $key => $value) {
                updateConfig($key, $value);
            }
            $message = 'Settings updated successfully!';
            $messageType = 'success';
            break;

        case 'add_banner':
            if (isset($_FILES['banner_image']) && $_FILES['banner_image']['error'] === 0) {
                $upload = uploadImage($_FILES['banner_image'], 'banners');
                if ($upload['success']) {
                    $title = $_POST['banner_title'] ?? '';
                    $subtitle = $_POST['banner_subtitle'] ?? '';
                    $order = (int) ($_POST['display_order'] ?? 0);
                    addBanner($upload['path'], $title, $subtitle, $order);
                    $message = 'Banner added successfully!';
                    $messageType = 'success';
                } else {
                    $message = $upload['message'];
                    $messageType = 'error';
                }
            } else {
                $message = 'Please select an image to upload.';
                $messageType = 'error';
            }
            break;

        case 'delete_banner':
            $id = (int) ($_POST['id'] ?? 0);
            if ($id && deleteBanner($id)) {
                $message = 'Banner deleted successfully!';
                $messageType = 'success';
            }
            break;

        case 'add_car':
            if (isset($_FILES['car_image']) && $_FILES['car_image']['error'] === 0) {
                $upload = uploadImage($_FILES['car_image'], 'cars');
                if ($upload['success']) {
                    $name = $_POST['car_name'] ?? '';
                    $carSection = $_POST['car_section'] ?? 'latest';
                    $price = (float) ($_POST['car_price'] ?? 0);
                    $fuelType = $_POST['fuel_type'] ?? '';
                    $transmission = $_POST['transmission'] ?? '';
                    addCar($name, $upload['path'], $carSection, $price, $fuelType, $transmission);
                    $message = 'Car added successfully!';
                    $messageType = 'success';
                } else {
                    $message = $upload['message'];
                    $messageType = 'error';
                }
            } else {
                $message = 'Please select an image to upload.';
                $messageType = 'error';
            }
            break;

        case 'delete_car':
            $id = (int) ($_POST['id'] ?? 0);
            if ($id && deleteCar($id)) {
                $message = 'Car deleted successfully!';
                $messageType = 'success';
            }
            break;
    }
}

// Get data
$siteTitle = getConfig('site_title') ?: 'CarsDekho';
$banners = getBanners();
$cars = getAllCars();
$inquiries = getAllInquiries();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel -
        <?php echo htmlspecialchars($siteTitle); ?>
    </title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="admin-logo">Cars<span>Dekho</span> Admin</div>
            <ul class="admin-nav">
                <li><a href="?section=dashboard" class="<?php echo $section === 'dashboard' ? 'active' : ''; ?>">
                        Dashboard</a></li>
                <li><a href="?section=config" class="<?php echo $section === 'config' ? 'active' : ''; ?>">Site
                        Settings</a></li>
                <li><a href="?section=banners" class="<?php echo $section === 'banners' ? 'active' : ''; ?>">
                        Banners</a></li>
                <li><a href="?section=cars" class="<?php echo $section === 'cars' ? 'active' : ''; ?>"> Cars</a></li>
                <li><a href="?section=inquiries" class="<?php echo $section === 'inquiries' ? 'active' : ''; ?>">
                        Inquiries</a></li>
                <li><a href="../index.php"> View Site</a></li>
                <li><a href="logout.php" style="color: #dc3545;"> Logout</a></li>

            </ul>
        </aside>

        <!-- Main Content -->
        <main class="admin-main">
            <div class="admin-header">
                <h1 class="admin-title">
                    <?php
                    switch ($section) {
                        case 'config':
                            echo ' Site Settings';
                            break;
                        case 'banners':
                            echo ' Manage Banners';
                            break;
                        case 'cars':
                            echo ' Manage Cars';
                            break;
                        case 'inquiries':
                            echo ' Customer Inquiries';
                            break;
                        default:
                            echo ' Dashboard';
                    }
                    ?>
                </h1>
                <a href="../index.php" class="btn btn-secondary btn-sm">View Website</a>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if ($section === 'dashboard'): ?>
                <!-- Dashboard -->
                <div
                    style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                    <div class="admin-card" style="text-align: center;">
                        <h3 style="font-size: 2.5rem; color: var(--primary);">
                            <?php echo count($banners); ?>
                        </h3>
                        <p style="color: var(--gray);">Total Banners</p>
                    </div>
                    <div class="admin-card" style="text-align: center;">
                        <h3 style="font-size: 2.5rem; color: var(--secondary-light);">
                            <?php echo count($cars); ?>
                        </h3>
                        <p style="color: var(--gray);">Total Cars</p>
                    </div>
                    <div class="admin-card" style="text-align: center;">
                        <h3 style="font-size: 2.5rem; color: #28a745;">
                            <?php echo count($inquiries); ?>
                        </h3>
                        <p style="color: var(--gray);">Total Inquiries</p>
                    </div>
                </div>

                <div class="admin-card">
                    <h3 class="admin-card-title">Recent Inquiries</h3>
                    <?php if (empty($inquiries)): ?>
                        <p style="color: var(--gray);">No inquiries yet.</p>
                    <?php else: ?>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Car Types</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($inquiries, 0, 5) as $inquiry): ?>
                                    <tr>
                                        <td>
                                            <?php echo htmlspecialchars($inquiry['name']); ?>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($inquiry['phone']); ?>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($inquiry['car_options']); ?>
                                        </td>
                                        <td>
                                            <?php echo date('d M Y', strtotime($inquiry['created_at'])); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

            <?php elseif ($section === 'config'): ?>
                <!-- Site Settings -->
                <div class="admin-card">
                    <h3 class="admin-card-title">Header & Footer Settings</h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="update_config">
                        <div class="form-group">
                            <label class="form-label">Site Title</label>
                            <input type="text" name="config[site_title]" class="form-input"
                                value="<?php echo htmlspecialchars(getConfig('site_title')); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Header Tagline</label>
                            <input type="text" name="config[header_tagline]" class="form-input"
                                value="<?php echo htmlspecialchars(getConfig('header_tagline')); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Contact Email</label>
                            <input type="email" name="config[contact_email]" class="form-input"
                                value="<?php echo htmlspecialchars(getConfig('contact_email')); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Contact Phone</label>
                            <input type="text" name="config[contact_phone]" class="form-input"
                                value="<?php echo htmlspecialchars(getConfig('contact_phone')); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Footer Text</label>
                            <input type="text" name="config[footer_text]" class="form-input"
                                value="<?php echo htmlspecialchars(getConfig('footer_text')); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Save Settings</button>
                    </form>
                </div>

            <?php elseif ($section === 'banners'): ?>
                <!-- Banners Management -->
                <div class="admin-card">
                    <h3 class="admin-card-title">Add New Banner</h3>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="add_banner">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Banner Image *</label>
                                <input type="file" name="banner_image" class="form-input" accept="image/*" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Display Order</label>
                                <input type="number" name="display_order" class="form-input" value="0">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Title (optional)</label>
                                <input type="text" name="banner_title" class="form-input" placeholder="Banner headline">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Subtitle (optional)</label>
                                <input type="text" name="banner_subtitle" class="form-input" placeholder="Banner subtext">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Upload Banner</button>
                    </form>
                </div>

                <div class="admin-card">
                    <h3 class="admin-card-title">Current Banners</h3>
                    <?php if (empty($banners)): ?>
                        <p style="color: var(--gray);">No banners added yet.</p>
                    <?php else: ?>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Title</th>
                                    <th>Order</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($banners as $banner): ?>
                                    <tr>
                                        <td><img src="../<?php echo htmlspecialchars($banner['image_path']); ?>" alt="Banner"></td>
                                        <td>
                                            <?php echo htmlspecialchars($banner['title'] ?: '-'); ?>
                                        </td>
                                        <td>
                                            <?php echo $banner['display_order']; ?>
                                        </td>
                                        <td>
                                            <form method="POST" style="display: inline;"
                                                onsubmit="return confirm('Delete this banner?');">
                                                <input type="hidden" name="action" value="delete_banner">
                                                <input type="hidden" name="id" value="<?php echo $banner['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

            <?php elseif ($section === 'cars'): ?>
                <!-- Cars Management -->
                <div class="admin-card">
                    <h3 class="admin-card-title">Add New Car</h3>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="add_car">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Car Name *</label>
                                <input type="text" name="car_name" class="form-input" placeholder="e.g., Maruti Swift"
                                    required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Section *</label>
                                <select name="car_section" class="form-input" required>
                                    <option value="most_searched">Most Searched</option>
                                    <option value="latest">Latest Cars</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Price (₹) *</label>
                                <input type="number" name="car_price" class="form-input" placeholder="e.g., 800000"
                                    required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Car Image *</label>
                                <input type="file" name="car_image" class="form-input" accept="image/*" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Fuel Type</label>
                                <select name="fuel_type" class="form-input">
                                    <option value="">Select</option>
                                    <option value="Petrol">Petrol</option>
                                    <option value="Diesel">Diesel</option>
                                    <option value="CNG">CNG</option>
                                    <option value="Electric">Electric</option>
                                    <option value="Hybrid">Hybrid</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Transmission</label>
                                <select name="transmission" class="form-input">
                                    <option value="">Select</option>
                                    <option value="Manual">Manual</option>
                                    <option value="Automatic">Automatic</option>
                                    <option value="AMT">AMT</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Car</button>
                    </form>
                </div>

                <div class="admin-card">
                    <h3 class="admin-card-title">All Cars</h3>
                    <?php if (empty($cars)): ?>
                        <p style="color: var(--gray);">No cars added yet.</p>
                    <?php else: ?>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Section</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cars as $car): ?>
                                    <tr>
                                        <td><img src="../<?php echo htmlspecialchars($car['image_path']); ?>"
                                                alt="<?php echo htmlspecialchars($car['name']); ?>"></td>
                                        <td>
                                            <?php echo htmlspecialchars($car['name']); ?>
                                        </td>
                                        <td>
                                            <?php echo ucwords(str_replace('_', ' ', $car['section'])); ?>
                                        </td>
                                        <td>₹
                                            <?php echo number_format($car['price']); ?>
                                        </td>
                                        <td>
                                            <form method="POST" style="display: inline;"
                                                onsubmit="return confirm('Delete this car?');">
                                                <input type="hidden" name="action" value="delete_car">
                                                <input type="hidden" name="id" value="<?php echo $car['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

            <?php elseif ($section === 'inquiries'): ?>
                <!-- Inquiries -->
                <div class="admin-card">
                    <h3 class="admin-card-title">All Customer Inquiries</h3>
                    <?php if (empty($inquiries)): ?>
                        <p style="color: var(--gray);">No inquiries received yet.</p>
                    <?php else: ?>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Address</th>
                                    <th>Car Types</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($inquiries as $inquiry): ?>
                                    <tr>
                                        <td>
                                            <?php echo htmlspecialchars($inquiry['name']); ?>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($inquiry['phone']); ?>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($inquiry['email']); ?>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars(substr($inquiry['address'], 0, 50)) . (strlen($inquiry['address']) > 50 ? '...' : ''); ?>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($inquiry['car_options']); ?>
                                        </td>
                                        <td>
                                            <?php echo date('d M Y H:i', strtotime($inquiry['created_at'])); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>

</html>