<?php
require_once 'includes/functions.php';

$siteTitle = getConfig('site_title') ?: 'CarBazaar';
$tagline = getConfig('header_tagline') ?: 'Find Your Perfect Car';
$banners = getBanners();
$mostSearchedCars = getCarsBySection('most_searched');
$latestCars = getCarsBySection('latest');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo htmlspecialchars($siteTitle); ?> -
        <?php echo htmlspecialchars($tagline); ?>
    </title>
    <meta name="description"
        content="Find your dream car at Cars. Browse the most searched and latest cars with best prices.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    
    <header class="header">
        <div class="header-container">
            <a href="index.php" class="logo">
                <div class="logo-icon"></div>
                Cars<span>Bazaar</span>
            </a>
            <nav class="nav">
                <a href="index.php" class="nav-link">Home</a>
                <a href="#most-searched" class="nav-link">Popular Cars</a>
                <a href="#latest" class="nav-link">Latest Cars</a>
                <a href="inquiry.php" class="btn btn-primary">Get Quote</a>
            </nav>
        </div>
    </header>

    
    <section class="hero">
        <div class="hero-container">
            <div class="hero-content">
                <span class="hero-tagline">India's #1 Auto Market</span>
                <h1 class="hero-title">
                    Find Your <span>Dream Car</span> Today
                </h1>
                <p class="hero-description">
                    Discover the perfect vehicle from our extensive collection of hatchbacks, sedans, and SUVs. Your
                    journey begins here.
                </p>
                <div class="hero-buttons">
                    <a href="inquiry.php" class="btn btn-primary">Get Started →</a>
                    <a href="#most-searched" class="btn btn-outline" style="border-color: white; color: white;">Explore
                        Cars</a>
                </div>
            </div>
            <div class="hero-image">
                <?php if (!empty($banners)): ?>
                    <div class="banner-slider">
                        <?php foreach ($banners as $index => $banner): ?>
                            <div class="banner-slide <?php echo $index === 0 ? 'active' : ''; ?>">
                                <img src="<?php echo htmlspecialchars($banner['image_path']); ?>"
                                    alt="<?php echo htmlspecialchars($banner['title'] ?: 'Banner'); ?>">
                                <?php if ($banner['title'] || $banner['subtitle']): ?>
                                    <div class="banner-content">
                                        <?php if ($banner['title']): ?>
                                            <h2 style="font-size: 2rem; margin-bottom: 0.5rem;">
                                                <?php echo htmlspecialchars($banner['title']); ?>
                                            </h2>
                                        <?php endif; ?>
                                        <?php if ($banner['subtitle']): ?>
                                            <p style="font-size: 1.2rem; opacity: 0.9;">
                                                <?php echo htmlspecialchars($banner['subtitle']); ?>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                        <?php if (count($banners) > 1): ?>
                            <div class="banner-dots">
                                <?php foreach ($banners as $index => $banner): ?>
                                    <span class="banner-dot <?php echo $index === 0 ? 'active' : ''; ?>"
                                        data-index="<?php echo $index; ?>"></span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div
                        style="background: linear-gradient(135deg, rgba(230,57,70,0.3), rgba(247,127,0,0.3)); border-radius: 20px; padding: 3rem; text-align: center; color: white;">
                        <h2 style="font-size: 2rem; margin-bottom: 1rem;">Welcome to Cars market</h2>
                        <p>Showcase your featured cars with admin-managed banners.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    
    <section class="section" id="most-searched" style="background: white;">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Most <span>Searched</span> Cars</h2>
                <p class="section-subtitle">Discover the cars everyone is talking about</p>
            </div>

            <?php if (!empty($mostSearchedCars)): ?>
                <div class="cars-grid">
                    <?php foreach ($mostSearchedCars as $car): ?>
                        <div class="car-card">
                            <div class="car-card-image">
                                <img src="<?php echo htmlspecialchars($car['image_path']); ?>"
                                    alt="<?php echo htmlspecialchars($car['name']); ?>">
                                <span class="car-card-badge"> Popular</span>
                            </div>
                            <div class="car-card-body">
                                <h3 class="car-card-title">
                                    <?php echo htmlspecialchars($car['name']); ?>
                                </h3>
                                <div class="car-card-specs">
                                    <?php if ($car['fuel_type']): ?>
                                        <span class="car-card-spec">
                                            <?php echo htmlspecialchars($car['fuel_type']); ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if ($car['transmission']): ?>
                                        <span class="car-card-spec">
                                            <?php echo htmlspecialchars($car['transmission']); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="car-card-price">
                                    ₹
                                    <?php echo number_format($car['price']); ?> <span>onwards</span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 3rem; background: var(--light); border-radius: var(--radius);">
                    <p style="color: var(--gray); font-size: 1.1rem;">No cars added yet. Add cars from the <a
                            href="admin/index.php?section=cars" style="color: var(--primary);">admin panel</a>.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>


    <section class="section" id="latest" style="background: var(--light);">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Latest <span>Cars</span></h2>
                <p class="section-subtitle">Fresh arrivals you don't want to miss</p>
            </div>

            <?php if (!empty($latestCars)): ?>
                <div class="cars-grid">
                    <?php foreach ($latestCars as $car): ?>
                        <div class="car-card">
                            <div class="car-card-image">
                                <img src="<?php echo htmlspecialchars($car['image_path']); ?>"
                                    alt="<?php echo htmlspecialchars($car['name']); ?>">
                                <span class="car-card-badge" style="background: linear-gradient(135deg, #28a745, #20c997);">
                                    New</span>
                            </div>
                            <div class="car-card-body">
                                <h3 class="car-card-title">
                                    <?php echo htmlspecialchars($car['name']); ?>
                                </h3>
                                <div class="car-card-specs">
                                    <?php if ($car['fuel_type']): ?>
                                        <span class="car-card-spec">
                                            <?php echo htmlspecialchars($car['fuel_type']); ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if ($car['transmission']): ?>
                                        <span class="car-card-spec">
                                            <?php echo htmlspecialchars($car['transmission']); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="car-card-price">
                                    ₹
                                    <?php echo number_format($car['price']); ?> <span>onwards</span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 3rem; background: white; border-radius: var(--radius);">
                    <p style="color: var(--gray); font-size: 1.1rem;">No latest cars added yet. Add cars from the <a
                            href="admin/index.php?section=cars" style="color: var(--primary);">admin panel</a>.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    
    <section class="section form-section">
        <div style="max-width: 800px; margin: 0 auto; text-align: center; position: relative; z-index: 1;">
            <h2 style="font-size: 2.5rem; color: white; margin-bottom: 1rem;">Ready to Find Your Dream Car?</h2>
            <p style="font-size: 1.2rem; color: rgba(255,255,255,0.8); margin-bottom: 2rem;">
                Submit your inquiry today and let our experts help you find the perfect vehicle.
            </p>
            <a href="inquiry.php" class="btn btn-primary" style="font-size: 1.1rem; padding: 1rem 2.5rem;">
                Get Your Free Quote 
            </a>
        </div>
    </section>

    
    <footer class="footer">
        <div class="footer-container">
            <div>
                <div class="footer-brand">Cars<span>Dekho</span></div>
                <p class="footer-description">Find your perfect car with India's leading automobile platform. Browse
                    thousands of cars and get the best deals.</p>
            </div>
            <div>
                <h4 class="footer-title">Quick Links</h4>
                <ul class="footer-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#most-searched">Popular Cars</a></li>
                    <li><a href="#latest">Latest Cars</a></li>
                    <li><a href="inquiry.php">Get Quote</a></li>
                </ul>
            </div>
            <div>
                <h4 class="footer-title">Car Types</h4>
                <ul class="footer-links">
                    <li><a href="#">Hatchback</a></li>
                    <li><a href="#">Sedan</a></li>
                    <li><a href="#">SUV</a></li>
                    <li><a href="#">Electric</a></li>
                </ul>
            </div>
            <div>
                <h4 class="footer-title">Contact Us</h4>
                <ul class="footer-links">
                    <li>
                        <?php echo htmlspecialchars(getConfig('contact_email') ?: 'info@carsmarket.com'); ?>
                    </li>
                    <li>
                        <?php echo htmlspecialchars(getConfig('contact_phone') ?: '+91 9876543210'); ?>
                    </li>
                    <li> New Delhi, India</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>
                <?php echo htmlspecialchars(getConfig('footer_text') ?: '© 2026 CarsDekho. All Rights Reserved.'); ?>
            </p>
        </div>
    </footer>

    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const slides = document.querySelectorAll('.banner-slide');
            const dots = document.querySelectorAll('.banner-dot');
            let currentSlide = 0;

            if (slides.length > 1) {
                function showSlide(index) {
                    slides.forEach((slide, i) => {
                        slide.classList.toggle('active', i === index);
                    });
                    dots.forEach((dot, i) => {
                        dot.classList.toggle('active', i === index);
                    });
                    currentSlide = index;
                }

                
                setInterval(() => {
                    const next = (currentSlide + 1) % slides.length;
                    showSlide(next);
                }, 5000);

                
                dots.forEach((dot, index) => {
                    dot.addEventListener('click', () => showSlide(index));
                });
            }
        });
    </script>
</body>

</html>